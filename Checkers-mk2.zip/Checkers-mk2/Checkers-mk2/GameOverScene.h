//
//  GameOverScene.h
//  Checkers-mk2
//
//  Created by LukeClayton on 30/03/2016.
//  Copyright © 2016 LukeClayton. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameOverScene : SKScene

@end
