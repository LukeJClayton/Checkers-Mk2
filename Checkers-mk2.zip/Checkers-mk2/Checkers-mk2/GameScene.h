//
//  GameScene.h
//  Checkers-mk2
//

//  Copyright (c) 2016 LukeClayton. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene

@end
